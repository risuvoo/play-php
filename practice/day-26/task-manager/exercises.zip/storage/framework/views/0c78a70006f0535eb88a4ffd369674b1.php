<?php $__env->startSection('title', __('Server Error')); ?>
<?php $__env->startSection('code', '500'); ?>
<?php $__env->startSection('message', __('Server Error')); ?>

<?php echo $__env->make('errors::minimal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\apache\play-php\practice\day-24\exercise-1\task-manager\vendor\laravel\framework\src\Illuminate\Foundation\Exceptions\views/500.blade.php ENDPATH**/ ?>