<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact</title>
</head>
<body>
    <h1>This is a contact page</h1>
</body>
</html><?php /**PATH G:\apache\play-php\practice\day-26\task-manager\resources\views/contact/index.blade.php ENDPATH**/ ?>