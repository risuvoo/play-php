<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" <?php echo e($attributes); ?>>
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
</svg>
<?php /**PATH G:\apache\play-php\practice\day-24\exercise-1\task-manager\vendor\laravel\framework\src\Illuminate\Foundation\resources\exceptions\renderer/components/icons/check.blade.php ENDPATH**/ ?>