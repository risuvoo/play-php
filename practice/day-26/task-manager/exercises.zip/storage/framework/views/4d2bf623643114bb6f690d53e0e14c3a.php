<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Task</title>
</head>
<body>
    <h1>All Tasks show here</h1>
</body>
</html><?php /**PATH G:\apache\play-php\practice\day-26\task-manager\resources\views/tasks/index.blade.php ENDPATH**/ ?>