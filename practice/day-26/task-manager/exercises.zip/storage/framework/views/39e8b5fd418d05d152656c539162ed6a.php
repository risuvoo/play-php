<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Services</title>
</head>
<body>
    <h1>
        This is services page
    </h1>
</body>
</html><?php /**PATH G:\apache\play-php\practice\day-26\task-manager\resources\views/services/index.blade.php ENDPATH**/ ?>