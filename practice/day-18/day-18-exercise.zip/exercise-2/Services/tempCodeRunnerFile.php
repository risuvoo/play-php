<?php
$order->show();